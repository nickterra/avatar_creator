﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class changeSkinTone : MonoBehaviour
{
    public Button skin1button;
    public Button skin2button;
    public Button skin3button;

    public GameObject skin_color;

    void Start()
    {
        Button blackbam = skin3button.GetComponent<Button>();
        blackbam.onClick.AddListener(changetoBlack);

        Button brownbam = skin2button.GetComponent<Button>();
        brownbam.onClick.AddListener(changetoBrown);

        Button blondebam = skin1button.GetComponent<Button>();
        blondebam.onClick.AddListener(changetoWhite);
    }

    public void changetoWhite()
    {
        skin_color.GetComponent<Renderer>().material.color = new Color(1.0F, 0.9F, 0.7F, 1.0F);
    }
    public void changetoBrown()
    {
        skin_color.GetComponent<Renderer>().material.color = new Color(0.8F, 0.5F, 0.0F, 1.0F);
    }
    public void changetoBlack()
    {
        skin_color.GetComponent<Renderer>().material.color = new Color(0.5F, 0.2F, 0.0F, 1.0F);
    }
}