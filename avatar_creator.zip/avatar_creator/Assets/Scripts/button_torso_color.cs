﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class button_torso_color : MonoBehaviour
{
    public Button color_button;
    public GameObject torso_color;
    public Color color;

    void Start()
    {
        Button bam = color_button.GetComponent<Button>();
        bam.onClick.AddListener(OnClickColor1);

    }

    void OnClickColor1()
    {
        torso_color.GetComponent<Renderer>().material.color = Color.green;
        torso_color.GetComponent<Renderer>().material.color = color;
    }
}