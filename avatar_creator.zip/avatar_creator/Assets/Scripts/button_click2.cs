﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class button_click2 : MonoBehaviour
{
    public GameObject hat;
    public GameObject new_hat;

    public Button hat_button;

    void Start()
    {
        Button yellow_hat = hat_button.GetComponent<Button>();

        yellow_hat.onClick.AddListener(OnClickHat1);

    }

    void OnClickHat1()
    {
        new_hat = Instantiate(hat, new Vector3(-3, 0, 0), Quaternion.identity) as GameObject;
        new_hat.SetActive(true);

        //if (new_hat == true)
            //Destroy(new_hat, 2.0f);
    }

    /*
    void OnTriggerEnter2D(Collider2D co)
    {
        if (co.name == "Yellow_Hat_Object")
        {
            Destroy(gameObject);
        }
        else if (co.name == "Tribe_Hat_Object")
        {
            Destroy(gameObject);
        }
    }*/
}
