﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class button_click : MonoBehaviour {
    public GameObject shirt;
    public GameObject new_shirt;

    public Button red_button;

    void Start()
    { 
        Button red_shirt = red_button.GetComponent<Button>();
        red_shirt.onClick.AddListener(OnClickShirt1);
    }

    void OnClickShirt1()
    {
        
        new_shirt = Instantiate(shirt, new Vector3(-3, 0, 0), Quaternion.identity) as GameObject;
        new_shirt.SetActive(true);
    }
}


