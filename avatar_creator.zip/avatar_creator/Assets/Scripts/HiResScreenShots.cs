﻿using UnityEngine;
using System.Collections;
using System.IO;

public class HiResScreenShots : MonoBehaviour
{
    public RectTransform rectT; // Assign the UI element which you wanna capture
    int width; // width of the object to capture
    int height; // height of the object to capture
    public GameObject gameCam = null;

    public GameObject tex = null;
    byte[] fileData;

    // Use this for initialization
    void Start()
    {
        width = System.Convert.ToInt32(rectT.rect.width);
        height = System.Convert.ToInt32(rectT.rect.height);
        gameCam.GetComponent<Camera>().clearFlags = CameraClearFlags.Skybox; //CHANGE CLEAR FLAGS BACK
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            gameCam.GetComponent<Camera>().clearFlags = CameraClearFlags.Nothing; //CHANGE CLEAR FLAGS FROM SKYBOX TO DON'T CLEAR
            StartCoroutine(takeScreenShot()); // screenshot of a particular UI Element.
            gameCam.GetComponent<Camera>().clearFlags = CameraClearFlags.Skybox; //CHANGE CLEAR FLAGS BACK
        }
        if (Input.GetKeyDown(KeyCode.A))
        {
            Application.CaptureScreenshot("FullPageScreenShot.png");
        }

    }
    public IEnumerator takeScreenShot()
    {
        yield return new WaitForEndOfFrame(); // it must be a coroutine 

        Vector2 temp = rectT.transform.position;
        var startX = temp.x;
        var startY = temp.y;

        var tex = new Texture2D(width, height, TextureFormat.RGB24, false);
        tex.ReadPixels(new Rect(startX, startY, width, height), 0, 0);
        tex.Apply();

        // Encode texture into PNG
        var bytes = tex.EncodeToPNG();
        Destroy(tex);

        File.WriteAllBytes(Application.persistentDataPath + "PersistentScreenShot.png", bytes);

        //This loads screenshot onto image in panel
        if (File.Exists(Application.persistentDataPath + "PersistentScreenShot.png"))
        {
            fileData = File.ReadAllBytes(Application.persistentDataPath + "PersistentScreenShot.png");
            tex = new Texture2D(2, 2);
            tex.LoadImage(fileData); //..this will auto-resize the texture dimensions.
        }

    }
}