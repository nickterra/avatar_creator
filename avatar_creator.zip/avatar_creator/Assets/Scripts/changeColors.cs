﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class changeColors : MonoBehaviour {
    public Button red_button;
    public Button orange_button;
    public Button yellow_button;
    public Button green_button;
    public Button cyan_button;
    public Button blue_button;
    public Button purple_button;
    public Button pink_button;

    public GameObject torso_color;

    void Start()
    {
        Button redbam = red_button.GetComponent<Button>();
        redbam.onClick.AddListener(changetoRed);

        Button orangebam = orange_button.GetComponent<Button>();
        orangebam.onClick.AddListener(changetoOrange);

        Button yellowbam = yellow_button.GetComponent<Button>();
        yellowbam.onClick.AddListener(changetoYellow);

        Button greenbam = green_button.GetComponent<Button>();
        greenbam.onClick.AddListener(changetoGreen);

        Button cyanbam = cyan_button.GetComponent<Button>();
        cyanbam.onClick.AddListener(changetoCyan);

        Button bluebam = blue_button.GetComponent<Button>();
        bluebam.onClick.AddListener(changetoBlue);

        Button purplebam = purple_button.GetComponent<Button>();
        purplebam.onClick.AddListener(changetoPurple);

        Button pinkbam = pink_button.GetComponent<Button>();
        pinkbam.onClick.AddListener(changetoPink);
    }


    public void changetoRed()
    {
        //torso_color.GetComponent<Renderer>().material.color = new Color32(114, 0, 0, 0);
        torso_color.GetComponent<Renderer>().material.color = Color.red;
    }
    public void changetoOrange()
    {
        torso_color.GetComponent<Renderer>().material.color = new Color(1.0F, 0.4F, 0.0F, 1.0F);
    }
    public void changetoYellow()
    {
        torso_color.GetComponent<Renderer>().material.color = new Color(1.0F, 0.9F, 0.0F, 1.0F);
    }
    public void changetoGreen()
    {
        torso_color.GetComponent<Renderer>().material.color = new Color(0.0F, 1.0F, 0.0F, 1.0F);
    }
    public void changetoCyan()
    {
        torso_color.GetComponent<Renderer>().material.color = new Color(0.0F, 0.9F, 1.0F, 1.0F);
    }
    public void changetoBlue()
    {
        torso_color.GetComponent<Renderer>().material.color = new Color(0.0F, 0.0F, 1.0F, 1.0F);
    }
    public void changetoPurple()
    {
        torso_color.GetComponent<Renderer>().material.color = new Color(0.8F, 0.0F, 1.0F, 1.0F);
    }
    public void changetoPink()
    {
        torso_color.GetComponent<Renderer>().material.color = new Color(1.0F, 0.6F, 0.8F, 1.0F);
    }

}
