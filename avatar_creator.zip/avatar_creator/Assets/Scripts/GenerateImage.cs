﻿using UnityEngine;
using System.Collections;

public class GenerateImage : MonoBehaviour {

    public TextAsset imageTextAsset;
    void Start()
    {
        Texture2D tex = new Texture2D(4, 4);
        tex.LoadImage(imageTextAsset.bytes);
        GetComponent<Renderer>().material.mainTexture = tex;
    }
}