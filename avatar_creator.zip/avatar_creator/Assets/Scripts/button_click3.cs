﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class button_click3 : MonoBehaviour
{

    public GameObject hair;
    public GameObject new_style;

    public Button style_button;
    public Button hair_color;

    void Start()
    {
        Button hairstyle = style_button.GetComponent<Button>();
        hairstyle.onClick.AddListener(OnClickHair1);
        //Button haircolor = style_button.GetComponent<Button>();
        //haircolor.onClick.AddListener(OnClickColor);

    }

    void OnClickHair1()
    {
        new_style = Instantiate(hair, new Vector3(-3, 0, 0), Quaternion.identity) as GameObject;
        new_style.SetActive(true);
    }

    /*
    void OnClickColor()
    {
       new_style.GetComponent<Renderer>().material.color = Color.yellow;
    }
    */
}