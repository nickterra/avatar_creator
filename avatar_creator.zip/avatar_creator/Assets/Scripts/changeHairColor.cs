﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class changeHairColor : MonoBehaviour
{
    public Button black_button;
    public Button brown_button;
    public Button blonde_button;
    public Button red_button;

    public GameObject hair_color;

    void Start()
    {
        Button blackbam = black_button.GetComponent<Button>();
        blackbam.onClick.AddListener(changetoBlack);

        Button brownbam = brown_button.GetComponent<Button>();
        brownbam.onClick.AddListener(changetoBrown);

        Button blondebam = blonde_button.GetComponent<Button>();
        blondebam.onClick.AddListener(changetoBlonde);

        Button redbam = red_button.GetComponent<Button>();
        redbam.onClick.AddListener(changetoRed);
    }

    public void changetoBlack()
    {
        hair_color.GetComponent<Renderer>().material.color = new Color(0.0F, 0.0F, 0.0F, 1.0F);
    }
    public void changetoBrown()
    {
        hair_color.GetComponent<Renderer>().material.color = new Color(0.5F, 0.2F, 0.0F, 1.0F);
    }
    public void changetoBlonde()
    {
        hair_color.GetComponent<Renderer>().material.color = new Color(0.8F, 0.7F, 0.1F, 1.0F);
    }
    public void changetoRed()
    {
        hair_color.GetComponent<Renderer>().material.color = new Color(1.0F, 0.4F, 0.0F, 1.0F);
    }
}