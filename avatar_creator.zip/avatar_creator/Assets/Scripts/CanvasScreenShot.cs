﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.IO;

public class CanvasScreenShot : MonoBehaviour
{
    public void OnClickScreenCaptureButton()
    {
        StartCoroutine(CaptureScreen());
    }
    public IEnumerator CaptureScreen()
    {
        // Wait till the last possible moment before screen rendering to hide the UI
        yield return null;
        GameObject.Find("MyCanvas").GetComponent<Canvas>().enabled = false;

        // Wait for screen rendering to complete
        yield return new WaitForEndOfFrame();

        // Take screenshot
        Application.CaptureScreenshot("mycanvas.png");

        // Show UI after we're done
        GameObject.Find("MyCanvas").GetComponent<Canvas>().enabled = true;
    }
}